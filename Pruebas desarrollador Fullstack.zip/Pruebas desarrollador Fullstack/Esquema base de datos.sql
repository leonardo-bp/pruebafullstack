CREATE DATABASE IF NOT EXISTS `ejercicio_bd`;

USE `ejercicio_bd`;

CREATE TABLE IF NOT EXISTS `ejercicio_bd`.`Roles` (
  `idRoles` INT NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idRoles`));

CREATE TABLE IF NOT EXISTS `ejercicio_bd`.`Usuarios` (
  `idUsuarios` INT NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(45) NOT NULL,
  `correo` VARCHAR(45) NOT NULL,
  `contraseña` VARCHAR(45) NOT NULL,
  `Roles_idRoles` INT NOT NULL,
  PRIMARY KEY (`idUsuarios`),
  INDEX `fk_Usuarios_Roles_idx` (`Roles_idRoles` ASC) VISIBLE,
  UNIQUE INDEX `correo_UNIQUE` (`correo` ASC) VISIBLE,
  CONSTRAINT `fk_Usuarios_Roles`
    FOREIGN KEY (`Roles_idRoles`)
    REFERENCES `ejercicio_bd`.`Roles` (`idRoles`)
    ON DELETE RESTRICT
    ON UPDATE CASCADE);

USE ejercicio_bd;
INSERT INTO Roles(nombre) VALUES ("admin");

USE ejercicio_bd;
INSERT INTO Usuarios(nombre, correo, contraseña, Roles_idRoles) VALUES ("nombre1", "correonombre1@nombre1.com", "password", 1);

SELECT * FROM Roles;
SELECT * FROM Usuarios;