import React from "react";

const ListaOrdenada = ({ personas }) => {
  const personasOrdenasdas = [...personas].sort((a, b) => a.edad - b.edad);

  return (
    <div>
      <h1>Lista ordenada por edad</h1>
      <ol>
        {personasOrdenasdas.map((persona, index) => (
          <li key={index}>
            {persona.nombre} - {persona.edad} años
          </li>
        ))}
      </ol>
    </div>
  );
};

export default ListaOrdenada;
