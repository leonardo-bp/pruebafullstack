import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import ListaOrdenada from "./components/ListaOrdenada/ListaOrdenada";

const personas = [
  { nombre: "Nombre1", edad: 18 },
  { nombre: "Nombre2", edad: 25 },
  { nombre: "Nombre3", edad: 22 },
  { nombre: "Nombre4", edad: 35 },
  { nombre: "Nombre5", edad: 27 },
];

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<ListaOrdenada personas={personas} />);
