const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const routes = require("./routes/routes");

const app = express();

app.use(bodyParser.json());

mongoose.connect("mongodb://localhost:27017/mongo", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

app.use(routes);

app.listen(3000, () => {
  console.log("Servidor iniciado");
});
