const express = require("express");
const router = express.Router();
const Model = require("../models/model");

router.post("/agregar", async (req, res) => {
  const { nombre, correo, direccion, telefono } = req.body;
  const model = new Model({ nombre, correo, direccion, telefono });
  await model.save();
  res.json({ mensaje: "Usuario agregado correctamente" });
});

module.exports = router;
