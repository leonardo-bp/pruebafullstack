let numeros = [2, 7, 3, 8, 9, 4, 6, 12, 8, 10];

function ordenarNumeros(num) {
  return num.sort((a, b) => b - a);
}

console.log(ordenarNumeros(numeros));